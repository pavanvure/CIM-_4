package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);
    private static final int BATCH = 500;

    private final CimObjectRecordRepository repo;
    private final MongoTemplate             mongo;

    public StreamingReferenceResolver(CimObjectRecordRepository repo,
                                       MongoTemplate mongo) {
        this.repo  = repo;
        this.mongo = mongo;
    }

    public long resolveReferencesInMongo(String jobId, int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution: server-side $lookup+$merge");
        long start = System.currentTimeMillis();
        try {
            long n = serverSide(jobId, progress, start);
            progress.log("Server-side done in " + elapsed(start) + "s → " + n + " resolved");
            return n;
        } catch (Exception e) {
            log.warn("Server-side failed ({}), client-side fallback", e.getMessage());
            return clientSide(jobId, batchSize, progress, start);
        }
    }

    // ── Server-side $lookup + $merge ──────────────────────────────────────
    private long serverSide(String jobId, ProgressTracker progress, long start) {
        String pipeline = String.format(
            "{ aggregate: 'cim_objects', pipeline: ["
          + "  { $match: { jobId: '%s' } },"
          + "  { $addFields: { refArray: { $objectToArray: '$references' } } },"
          + "  { $lookup: { from: 'cim_objects', localField: 'refArray.v',"
          + "    foreignField: 'rdfId', as: 'rd',"
          + "    pipeline: [{ $match: { jobId: '%s' } },{ $project: { rdfId:1,_id:0 } }] } },"
          + "  { $addFields: { resolvedSet: '$rd.rdfId' } },"
          + "  { $addFields: { resolvedPairs: { $filter: { input:'$refArray',"
          + "    as:'p', cond:{ $in:['$$p.v','$resolvedSet'] } } } } },"
          + "  { $addFields: { resolvedRefIds: { $arrayToObject:'$resolvedPairs' } } },"
          + "  { $project: { resolvedRefIds:1 } },"
          + "  { $merge: { into:'cim_objects', on:'_id',"
          + "    whenMatched:'merge', whenNotMatched:'discard' } }"
          + "], cursor:{}, allowDiskUse:true}", jobId, jobId);

        mongo.getDb().runCommand(Document.parse(pipeline));
        progress.log("$merge done in " + elapsed(start) + "s");

        Criteria c = Criteria.where("resolvedRefIds").exists(true).ne(new Document());
        return mongo.count(new Query(Criteria.where("jobId").is(jobId).andOperator(c)), "cim_objects");
    }

    // ── Client-side fallback ──────────────────────────────────────────────
    private long clientSide(String jobId, int batchSize,
                             ProgressTracker progress, long start) {
        Set<String> targets  = collectTargets(jobId, progress);
        progress.log("Targets collected: " + targets.size() + " in " + elapsed(start) + "s");
        Set<String> existing = verifyExistence(jobId, targets);
        progress.log("Verified: " + existing.size() + "/" + targets.size());
        return writeBack(jobId, existing, batchSize, progress);
    }

    private Set<String> collectTargets(String jobId, ProgressTracker progress) {
        try {
            String pipe = String.format(
                "{ aggregate:'cim_objects', pipeline:["
              + "  { $match:{ jobId:'%s', references:{ $exists:true } } },"
              + "  { $project:{ _id:0, refs:{ $objectToArray:'$references' } } },"
              + "  { $unwind:'$refs' },"
              + "  { $group:{ _id:'$refs.v' } }"
              + "], cursor:{batchSize:50000}, allowDiskUse:true}", jobId);
            Document res = mongo.getDb().runCommand(Document.parse(pipe));
            Set<String> targets = new HashSet<>();
            Document cursor = (Document) res.get("cursor");
            if (cursor != null) {
                @SuppressWarnings("unchecked")
                List<Document> batch = (List<Document>) cursor.get("firstBatch");
                if (batch != null) batch.forEach(d -> {
                    Object id = d.get("_id");
                    if (id != null && !id.toString().isBlank()) targets.add(id.toString());
                });
            }
            return targets;
        } catch (Exception e) { return new HashSet<>(); }
    }

    private Set<String> verifyExistence(String jobId, Set<String> targets) {
        Set<String> found = new HashSet<>();
        List<String> list = new ArrayList<>(targets);
        for (int i = 0; i < list.size(); i += BATCH) {
            List<String> b = list.subList(i, Math.min(i+BATCH, list.size()));
            Query q = new Query(Criteria.where("jobId").is(jobId).and("rdfId").in(b));
            q.fields().include("rdfId").exclude("_id");
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));
            mongo.find(q, CimObjectRecord.class, "cim_objects")
                 .forEach(r -> { if (r.getRdfId() != null) found.add(r.getRdfId()); });
        }
        return found;
    }

    private long writeBack(String jobId, Set<String> existing,
                            int batchSize, ProgressTracker progress) {
        long total = 0; int page = 0;
        while (true) {
            List<CimObjectRecord> batch = repo.findByJobId(jobId,
                    PageRequest.of(page, batchSize)).getContent();
            if (batch.isEmpty()) break;
            BulkOperations bulk = mongo.bulkOps(BulkOperations.BulkMode.UNORDERED, "cim_objects");
            int upd = 0;
            for (CimObjectRecord rec : batch) {
                Map<String,String> refs = rec.getReferences();
                if (refs == null || refs.isEmpty()) continue;
                Map<String,String> resolved = new LinkedHashMap<>();
                MapKeySanitizer.decodeKeys(refs).forEach((k,v) -> {
                    if (existing.contains(v)) resolved.put(MapKeySanitizer.encode(k), v);
                });
                if (!resolved.isEmpty()) {
                    bulk.updateOne(new Query(Criteria.where("_id").is(rec.getId())),
                            new Update().set("resolvedRefIds", resolved));
                    total += resolved.size(); upd++;
                }
            }
            if (upd > 0) bulk.execute();
            page++;
        }
        return total;
    }

    private long elapsed(long start) { return (System.currentTimeMillis()-start)/1000; }
}
