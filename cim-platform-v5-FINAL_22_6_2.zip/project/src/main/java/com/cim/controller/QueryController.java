package com.cim.controller;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.bson.Document;

import java.util.*;

/**
 * Query API — objects, stats, isRequired management, path validation issues
 *
 * GET  /api/jobs/{jobId}/objects               list with filters
 * GET  /api/jobs/{jobId}/objects/stats         type breakdown
 * GET  /api/jobs/{jobId}/objects/path-issues   objects with INVALID path tags
 * GET  /api/objects/{id}                       single object
 * GET  /api/objects/{id}/required              get isRequired
 * PATCH /api/objects/{id}/required?value=      set one object
 * PATCH /api/jobs/{jobId}/objects/required     bulk set
 * PATCH /api/jobs/{jobId}/objects/required/reset  reset to OWL defaults
 * GET  /api/jobs/{jobId}/objects/required/summary
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class QueryController {

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongo;

    public QueryController(CimObjectRecordRepository objectRepo,
                            MongoTemplate mongo) {
        this.objectRepo = objectRepo;
        this.mongo      = mongo;
    }

    // ── Object queries ─────────────────────────────────────────────────────

    @GetMapping("/jobs/{jobId}/objects")
    public ResponseEntity<?> getObjects(
            @PathVariable String jobId,
            @RequestParam(required=false) String type,
            @RequestParam(required=false) String category,
            @RequestParam(required=false) Boolean required,
            @RequestParam(required=false) Boolean hasPathIssues,
            @RequestParam(required=false) String networkVersion,  // for context/filtering
            @RequestParam(required=false) String orgId,           // for context/filtering
            @RequestParam(defaultValue="0")  int page,
            @RequestParam(defaultValue="50") int size) {

        if (type != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndCimType(jobId, type));
        if (category != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndCategory(jobId, category.toUpperCase()));
        if (required != null) return ResponseEntity.ok(
                objectRepo.findByJobIdAndIsRequired(jobId, required));
        if (Boolean.TRUE.equals(hasPathIssues)) {
            Query q = new Query(Criteria.where("jobId").is(jobId)
                    .and("pathIssues").exists(true)
                    .and("pathIssues.0").exists(true));
            return ResponseEntity.ok(mongo.find(q, CimObjectRecord.class));
        }

        Page<CimObjectRecord> p = objectRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("cimType")));
        return ResponseEntity.ok(Map.of(
            "content", p.getContent(), "totalElements", p.getTotalElements(),
            "totalPages", p.getTotalPages(), "page", page, "size", size));
    }

    @GetMapping("/jobs/{jobId}/objects/stats")
    public ResponseEntity<?> getStats(@PathVariable String jobId) {
        long total    = objectRepo.countByJobId(jobId);
        long physical = objectRepo.countByJobIdAndCategory(jobId,"PHYSICAL");
        long logical  = objectRepo.countByJobIdAndCategory(jobId,"LOGICAL");
        long required = objectRepo.countByJobIdAndIsRequired(jobId, true);
        long withPathIssues = mongo.count(new Query(
                Criteria.where("jobId").is(jobId)
                        .and("pathIssues.0").exists(true)), "cim_objects");

        // Include version + orgId from the job for client context
        String version = "", orgId = "";
        var jobOpt = mongo.findOne(
                new Query(Criteria.where("jobId").is(jobId)),
                com.cim.model.mongo.ValidationJob.class, "validation_jobs");
        if (jobOpt != null) {
            version = jobOpt.getNetworkVersion() != null ? jobOpt.getNetworkVersion() : "";
            orgId   = jobOpt.getOrgId()          != null ? jobOpt.getOrgId()          : "";
        }

        return ResponseEntity.ok(Map.of(
            "jobId",          jobId,
            "networkVersion", version,
            "orgId",          orgId,
            "total",          total,
            "physical",       physical,
            "logical",        logical,
            "required",       required,
            "notRequired",    total - required,
            "withPathIssues", withPathIssues,
            "byType",         getTypeBreakdown(jobId)));
    }

    @GetMapping("/jobs/{jobId}/objects/path-issues")
    public ResponseEntity<?> getPathIssues(
            @PathVariable String jobId,
            @RequestParam(defaultValue="0")   int page,
            @RequestParam(defaultValue="100") int size) {
        Query q = new Query(Criteria.where("jobId").is(jobId)
                .and("pathIssues.0").exists(true))
                .with(PageRequest.of(page, size));
        List<CimObjectRecord> issues = mongo.find(q, CimObjectRecord.class);
        long total = mongo.count(new Query(Criteria.where("jobId").is(jobId)
                .and("pathIssues.0").exists(true)), "cim_objects");
        return ResponseEntity.ok(Map.of(
            "content", issues, "total", total, "page", page, "size", size));
    }

    @GetMapping("/objects/{id}")
    public ResponseEntity<?> getObject(@PathVariable String id) {
        return objectRepo.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ── isRequired management ─────────────────────────────────────────────

    @GetMapping("/objects/{id}/required")
    public ResponseEntity<?> getRequired(@PathVariable String id) {
        return objectRepo.findById(id).map(o -> ResponseEntity.ok(Map.of(
            "id", o.getId(), "rdfId", o.getRdfId(), "cimType", o.getCimType(),
            "name", o.getName() != null ? o.getName() : "",
            "category", o.getCategory(), "isRequired", o.isRequired()
        ))).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/objects/{id}/required")
    public ResponseEntity<?> setRequired(@PathVariable String id,
                                          @RequestParam boolean value) {
        return objectRepo.findById(id).map(o -> {
            boolean old = o.isRequired();
            o.setRequired(value); objectRepo.save(o);
            return ResponseEntity.ok(Map.of(
                "id", o.getId(), "cimType", o.getCimType(),
                "isRequired", o.isRequired(), "changed", old != value,
                "message", "isRequired: " + old + " → " + value));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/jobs/{jobId}/objects/required")
    public ResponseEntity<?> bulkSetRequired(
            @PathVariable String jobId,
            @RequestParam boolean value,
            @RequestParam(required=false) String category,
            @RequestParam(required=false) String cimType) {

        Criteria c = Criteria.where("jobId").is(jobId);
        if (category != null && !category.isBlank())
            c = c.and("category").is(category.toUpperCase());
        if (cimType != null && !cimType.isBlank())
            c = c.and("cimType").is(cimType);

        long updated = mongo.updateMulti(new Query(c),
                new Update().set("isRequired", value), "cim_objects").getModifiedCount();

        return ResponseEntity.ok(Map.of(
            "message", "isRequired set to " + value,
            "jobId", jobId,
            "category", category != null ? category : "ALL",
            "cimType",  cimType  != null ? cimType  : "ALL",
            "updated",  updated));
    }

    /**
     * Reset isRequired to OWL defaults.
     * PHYSICAL → true, LOGICAL → false.
     * This uses the stored category (which was set from OWL at import time).
     */
    @PatchMapping("/jobs/{jobId}/objects/required/reset")
    public ResponseEntity<?> resetRequired(@PathVariable String jobId) {
        long p = mongo.updateMulti(
                new Query(Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL")),
                new Update().set("isRequired", true), "cim_objects").getModifiedCount();
        long l = mongo.updateMulti(
                new Query(Criteria.where("jobId").is(jobId).and("category").is("LOGICAL")),
                new Update().set("isRequired", false), "cim_objects").getModifiedCount();
        return ResponseEntity.ok(Map.of(
            "message", "isRequired reset to OWL defaults",
            "physicalSetTrue", p, "logicalSetFalse", l, "total", p+l));
    }

    @GetMapping("/jobs/{jobId}/objects/required/summary")
    public ResponseEntity<?> requiredSummary(@PathVariable String jobId) {
        long req   = objectRepo.countByJobIdAndIsRequired(jobId, true);
        long notReq= objectRepo.countByJobIdAndIsRequired(jobId, false);
        return ResponseEntity.ok(Map.of(
            "jobId", jobId, "total", req+notReq,
            "required", req, "notRequired", notReq,
            "breakdown", Map.of(
                "PHYSICAL", Map.of(
                    "required",    countWhere(jobId,"PHYSICAL",true),
                    "notRequired", countWhere(jobId,"PHYSICAL",false)),
                "LOGICAL", Map.of(
                    "required",    countWhere(jobId,"LOGICAL",true),
                    "notRequired", countWhere(jobId,"LOGICAL",false))
            )));
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private long countWhere(String jobId, String cat, boolean req) {
        return mongo.count(new Query(Criteria.where("jobId").is(jobId)
                .and("category").is(cat).and("isRequired").is(req)), "cim_objects");
    }

    private List<Map<String,Object>> getTypeBreakdown(String jobId) {
        try {
            var results = mongo.aggregate(Aggregation.newAggregation(
                    Aggregation.match(Criteria.where("jobId").is(jobId)),
                    Aggregation.group("cimType").count().as("count"),
                    Aggregation.sort(Sort.by(Sort.Direction.DESC,"count"))),
                    "cim_objects", Document.class);
            List<Map<String,Object>> list = new ArrayList<>();
            for (Document d : results.getMappedResults()) {
                Object t = d.get("_id");
                if (t == null || t.toString().isBlank()) continue;
                list.add(Map.of("type", t.toString(), "count", d.getInteger("count",0)));
            }
            return list;
        } catch (Exception e) { return Collections.emptyList(); }
    }
    /**
     * REQ #4: Re-run path validation for all objects in a job.
     * Call this after:
     *   - Updating namespace configs (enable/disable a namespace)
     *   - Uploading a new OWL file with updated hierarchy
     *   - Any change that affects what is valid/invalid
     *
     * Clears existing pathIssues and re-validates all objects against
     * current registry + namespace settings.
     *
     * POST /api/jobs/{jobId}/revalidate-paths
     */
    @PostMapping("/jobs/{jobId}/revalidate-paths")
    public ResponseEntity<?> revalidatePaths(
            @PathVariable String jobId,
            @Autowired com.cim.service.ImportService importService,
            @Autowired com.cim.service.NamespaceService namespaceService,
            @Autowired com.cim.validation.registry.CIMHierarchyRegistry registry) {

        long start = System.currentTimeMillis();
        long updated = 0;
        int page = 0;

        while (true) {
            Page<CimObjectRecord> result = objectRepo.findByJobId(jobId,
                    PageRequest.of(page, 500, Sort.by("id")));
            if (result.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();
            for (CimObjectRecord rec : result.getContent()) {
                List<Map<String,String>> issues = new ArrayList<>();

                // Re-evaluate each stored attribute tag
                com.cim.util.MapKeySanitizer.decodeKeys(rec.getAttributes())
                        .keySet().forEach(tag -> {
                    String prefix = namespaceService.extractPrefix(tag);
                    if (!namespaceService.isEnabled(prefix)) {
                        issues.add(Map.of(
                            "tag",         tag,
                            "status",      "UNKNOWN_NAMESPACE",
                            "explanation", "Namespace '" + prefix + "' is not enabled."
                        ));
                    } else if (namespaceService.shouldValidatePath(prefix)
                               && registry.isKnownClass(rec.getCimType())) {
                        var res = registry.validateAttributePath(rec.getCimType(), tag);
                        if (res.isInvalid()) issues.add(Map.of(
                            "tag",         tag,
                            "status",      "INVALID_PATH",
                            "explanation", res.getExplanation()
                        ));
                    }
                });

                rec.setPathIssues(issues);
                toUpdate.add(rec);
            }

            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
                updated += toUpdate.size();
            }
            page++;
        }

        return ResponseEntity.ok(Map.of(
            "message",    "Path revalidation complete",
            "jobId",      jobId,
            "revalidated", updated,
            "elapsedMs",  System.currentTimeMillis() - start
        ));
    }

}
