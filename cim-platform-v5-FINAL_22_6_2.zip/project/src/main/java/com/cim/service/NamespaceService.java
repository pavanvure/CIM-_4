package com.cim.service;

import com.cim.model.mongo.NamespaceConfig;
import com.cim.repository.NamespaceConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Namespace Configuration Service — Organisation-specific (Enhancement 1)
 *
 * ENHANCEMENT 1: org-specific namespace configs.
 *   orgId=null/blank → GLOBAL config, applies to all orgs.
 *   orgId="CAISO"    → only applies when importing CAISO files.
 *
 *   Priority during import:
 *     1. Org-specific config (orgId matches import orgId)
 *     2. Global config (orgId is null/blank)
 *     3. Default: disabled
 *
 * CACHE STRATEGY: load per import job (loadForJob/clearAfterJob).
 *   Each import loads a merged view: org-specific overrides global.
 */
@Service
public class NamespaceService {

    private static final Logger log = LoggerFactory.getLogger(NamespaceService.class);

    private final NamespaceConfigRepository repo;

    /**
     * Per-job cache: jobId → (prefix → NamespaceConfig)
     * Loaded fresh from MongoDB at job start.
     * Org-specific configs override global ones for same prefix.
     */
    private final ConcurrentHashMap<String, Map<String, NamespaceConfig>> jobCaches
            = new ConcurrentHashMap<>();

    public NamespaceService(NamespaceConfigRepository repo) {
        this.repo = repo;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initDefaults() {
        // Create global 'cim' namespace if not exists
        if (!repo.existsByPrefix("cim")) {
            NamespaceConfig cim = new NamespaceConfig(
                    "cim", "http://iec.ch/TC57/CIM100#",
                    true, true, "IEC CIM standard namespace");
            // orgId=null → global
            repo.save(cim);
            log.info("Default global 'cim' namespace created");
        }
        log.info("Namespace service ready — {} configs", repo.count());
    }

    // ── Job lifecycle ─────────────────────────────────────────────────────

    /**
     * Load namespace cache for a job.
     * Merges global configs with org-specific configs.
     * Org-specific config wins over global for same prefix.
     */
    public void loadForJob(String jobId, String orgId) {
        Map<String, NamespaceConfig> snapshot = new LinkedHashMap<>();

        // Step 1: Load global configs (orgId is null or blank)
        repo.findAll().stream()
                .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                .forEach(c -> snapshot.put(normalizePrefix(c.getPrefix()), c));

        // Step 2: Load org-specific configs — overrides globals for same prefix
        if (orgId != null && !orgId.isBlank()) {
            repo.findByOrgId(orgId.trim()).forEach(c ->
                    snapshot.put(normalizePrefix(c.getPrefix()), c));
        }

        jobCaches.put(jobId, snapshot);
        log.info("Namespace cache loaded for job={} orgId={}: {} configs",
                jobId, orgId, snapshot.size());
    }

    /** Clear cache after job completes (success or failure). */
    public void clearAfterJob(String jobId) {
        Map<String, NamespaceConfig> removed = jobCaches.remove(jobId);
        if (removed != null)
            log.info("Namespace cache cleared for job={}", jobId);
    }

    // ── HOT PATH — called ~34M times during 3.4M object import ───────────

    public boolean isEnabled(String jobId, String prefix) {
        Map<String, NamespaceConfig> cache = jobCaches.get(jobId);
        if (cache != null) {
            NamespaceConfig c = cache.get(normalizePrefix(prefix));
            return c != null && c.isEnabled();
        }
        log.warn("No namespace cache for job={}", jobId);
        return fallbackIsEnabled(null, prefix);
    }

    public boolean shouldValidatePath(String jobId, String prefix) {
        Map<String, NamespaceConfig> cache = jobCaches.get(jobId);
        if (cache != null) {
            NamespaceConfig c = cache.get(normalizePrefix(prefix));
            return c != null && c.isEnabled() && c.isValidatePath();
        }
        return false;
    }

    public String extractPrefix(String tag) {
        if (tag == null) return "cim";
        int i = tag.indexOf(':');
        return i > 0 ? tag.substring(0, i) : "cim";
    }

    // ── CRUD — org-aware ──────────────────────────────────────────────────

    public List<NamespaceConfig> getAll() {
        return repo.findAll();
    }

    public List<NamespaceConfig> getByOrg(String orgId) {
        if (orgId == null || orgId.isBlank()) return repo.findAll();
        // Return global + org-specific
        return repo.findAll().stream()
                .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank()
                        || orgId.trim().equals(c.getOrgId()))
                .collect(Collectors.toList());
    }

    public List<NamespaceConfig> getEnabled() {
        return repo.findByEnabled(true);
    }

    public Optional<NamespaceConfig> findByPrefix(String prefix) {
        return repo.findByPrefix(normalizePrefix(prefix));
    }

    public Optional<NamespaceConfig> findByOrgAndPrefix(String orgId, String prefix) {
        // Look for org-specific first, then global
        String p = normalizePrefix(prefix);
        if (orgId != null && !orgId.isBlank()) {
            Optional<NamespaceConfig> orgSpecific =
                    repo.findByOrgIdAndPrefix(orgId.trim(), p);
            if (orgSpecific.isPresent()) return orgSpecific;
        }
        return repo.findByPrefix(p);
    }

    public NamespaceConfig create(NamespaceConfig config, String createdBy) {
        String prefix = normalizePrefix(config.getPrefix());
        String orgId  = config.getOrgId() != null ? config.getOrgId().trim() : null;

        // Check for duplicate: same prefix + orgId combination
        if (orgId != null && !orgId.isBlank()) {
            if (repo.existsByOrgIdAndPrefix(orgId, prefix))
                throw new IllegalArgumentException(
                        "Namespace '" + prefix + "' already exists for org '" + orgId + "'.");
        } else {
            // Global config — check only global (orgId=null)
            if (repo.existsByPrefix(prefix) && repo.findByPrefix(prefix)
                    .map(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                    .orElse(false))
                throw new IllegalArgumentException(
                        "Global namespace '" + prefix + "' already exists.");
        }

        config.setPrefix(prefix);
        config.setOrgId(orgId);
        config.setCreatedBy(createdBy);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace created: prefix={} orgId={} enabled={} validatePath={}",
                prefix, orgId, saved.isEnabled(), saved.isValidatePath());
        return saved;
    }

    public NamespaceConfig update(String id, boolean enabled, boolean validatePath,
                                   String description) {
        NamespaceConfig config = repo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Namespace config id '" + id + "' not found."));
        config.setEnabled(enabled);
        config.setValidatePath(validatePath);
        if (description != null) config.setDescription(description);
        config.setUpdatedAt(Instant.now());
        NamespaceConfig saved = repo.save(config);
        log.info("Namespace updated: id={} prefix={} orgId={} enabled={} validatePath={}",
                id, saved.getPrefix(), saved.getOrgId(), enabled, validatePath);
        return saved;
    }

    public void delete(String id) {
        repo.findById(id).ifPresent(c -> {
            repo.delete(c);
            log.info("Namespace deleted: id={} prefix={} orgId={}", id, c.getPrefix(), c.getOrgId());
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private boolean fallbackIsEnabled(String orgId, String prefix) {
        String p = normalizePrefix(prefix);
        if (orgId != null && !orgId.isBlank()) {
            Optional<NamespaceConfig> org = repo.findByOrgIdAndPrefix(orgId, p);
            if (org.isPresent()) return org.get().isEnabled();
        }
        return repo.findByPrefix(p).map(NamespaceConfig::isEnabled).orElse(false);
    }

    private String normalizePrefix(String p) {
        return p == null ? "" : p.toLowerCase().trim();
    }
}
