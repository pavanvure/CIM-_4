package com.cim.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Revalidation Async Executor — runs work on Spring @Async thread pool.
 *
 * DESIGN: Takes a Supplier<CompletableFuture<Void>> instead of holding
 * a reference to RevalidationService. This breaks the circular dependency:
 *
 *   BEFORE (circular):
 *     RevalidationService  → RevalidationExecutor (setter inject)
 *     RevalidationExecutor → RevalidationService  (constructor inject)
 *
 *   AFTER (no cycle):
 *     RevalidationService  → RevalidationExecutor (setter inject)
 *     RevalidationExecutor → nobody               (stateless)
 *
 * RevalidationService passes a lambda that captures all needed state.
 * RevalidationExecutor just executes it on an @Async thread.
 */
@Component
public class RevalidationExecutor {

    /**
     * Executes the supplied work on a Spring-managed async thread.
     * The supplier is a lambda created by RevalidationService that
     * captures jobId, orgId, revalidationId etc. in its closure.
     *
     * @Async on this method is intercepted by Spring proxy →
     * runs on thread pool → HTTP thread returns immediately.
     */
    @Async
    public CompletableFuture<Void> runAsync(Supplier<CompletableFuture<Void>> work) {
        return work.get();
    }
}
