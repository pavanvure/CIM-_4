package com.cim.config;

import org.neo4j.driver.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * Neo4j Configuration — Java 11 + Neo4j Driver 4.4.x
 * Driver 5.x requires Java 17. Using 4.4.19 for Java 11 compatibility.
 * No Spring Data Neo4j starter — requires Java 17.
 */
@Configuration
public class Neo4jConfig {

    private static final Logger log = LoggerFactory.getLogger(Neo4jConfig.class);

    @Value("${neo4j.uri:bolt://localhost:7687}")
    private String uri;

    @Value("${neo4j.username:neo4j}")
    private String username;

    @Value("${neo4j.password:password}")
    private String password;

    @Bean
    public Driver neo4jDriver() {
        try {
            Driver driver = GraphDatabase.driver(uri,
                    AuthTokens.basic(username, password),
                    Config.builder()
                            .withMaxConnectionPoolSize(20)
                            .withConnectionAcquisitionTimeout(30, TimeUnit.SECONDS)
                            .withConnectionTimeout(15, TimeUnit.SECONDS)
                            .build());
            driver.verifyConnectivity();
            log.info("Neo4j connected: {} (driver 4.4.x / Java 11 mode)", uri);
            return driver;
        } catch (Exception e) {
            log.warn("Neo4j not available at startup: {}. Export will fail until connected.", e.getMessage());
            return GraphDatabase.driver(uri, AuthTokens.basic(username, password));
        }
    }
}
