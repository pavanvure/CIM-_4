package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.model.mongo.ExportRequest.VersionType;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.repository.Neo4jExportConfigRepository;
import com.cim.model.mongo.Neo4jExportConfig;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Neo4j Export Service — v5
 *
 * Changes from previous version:
 *
 * REQ #1 — Index drop/rebuild removed.
 *           Indexes are maintained live. Heap tuning handles performance.
 *
 * No :CIMNode routing label — removed per manager request.
 * Label-less indexes on nodeKey/version/orgId used instead.
 *           Nodes have ONLY their specific cimType label (:ACLineSegment etc).
 *           Matches your existing Neo4j topology structure.
 *
 * REQ #3 — Three version types per export:
 *           FULL      → stored with version "{version}-0"
 *           SANITISED → stored with version "{version}-1" (default)
 *           RATIONALISED → stored with version "{version}-2"
 *
 * REQ #4 — OrgId specific: export uses jobId orgId + req.orgId override.
 *
 * Performance: per-label constraints created upfront, batch=5000.
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:5000}")
    private int batchSize;

    private final Driver                     driver;
    private final MongoTemplate              mongo;
    private final CimObjectRecordRepository  objectRepo;
    private final Neo4jExportJobRepository   exportRepo;
    private final ValidationJobRepository    jobRepo;
    private final Neo4jExportConfigRepository configRepo;

    // Tracks labels that already have a constraint this export run
    private final Set<String> constrainedLabels = new HashSet<>();

    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) { this.executor = executor; }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo,
                               Neo4jExportConfigRepository configRepo) {
        this.driver      = driver;
        this.mongo       = mongo;
        this.objectRepo  = objectRepo;
        this.exportRepo  = exportRepo;
        this.jobRepo     = jobRepo;
        this.configRepo  = configRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    /**
     * Starts a Neo4j export.
     *
     * SINGLE variant:   uses req.versionType + req.cimTypes
     * MULTI variant:    uses req.fullCimTypes + sanitisedCimTypes + rationalisedCimTypes
     *                   triggers three separate async export jobs
     *
     * Returns the first job created (or a summary job for multi-variant).
     */
    public Neo4jExportJob startExport(ExportRequest req) {
        String jobOrgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "").orElse("");
        String orgId = (req.getOrgId() != null && !req.getOrgId().isBlank())
                       ? req.getOrgId().trim() : jobOrgId;

        String networkVersion = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "")
                .orElse("");

        if (req.isMultiVariant()) {
            return startMultiVariantExport(req, networkVersion, orgId);
        }

        // FROM_CONFIG: load cimTypes from stored Neo4jExportConfig
        if (req.getMode() == ExportRequest.ExportMode.FROM_CONFIG) {
            return startFromConfig(req, networkVersion, orgId);
        }

        // Single variant with explicit cimTypes in request
        return startSingleExport(req, networkVersion, orgId,
                req.getVersionType() != null
                        ? req.getVersionType() : ExportRequest.VersionType.SANITISED,
                req.getCimTypes());
    }

    /**
     * FROM_CONFIG: load the stored Neo4jExportConfig and decide:
     *
     *   Case 1 — versionType NOT set (null) OR all three lists populated in config:
     *     → Trigger ALL configured variants as multi-variant export.
     *     → FULL(-0) triggered if config.fullCimTypes is not empty.
     *     → SANITISED(-1) triggered if config.sanitisedCimTypes is not empty.
     *     → RATIONALISED(-2) triggered if config.rationalisedCimTypes is not empty.
     *
     *   Case 2 — versionType IS explicitly set (FULL / SANITISED / RATIONALISED):
     *     → Trigger only that specific variant.
     *     → e.g. versionType=RATIONALISED → only config.rationalisedCimTypes → {version}-2
     *
     * This way:
     *   triggerExport=true in revalidation (no versionType) → all three variants
     *   Manual export with versionType=SANITISED → only sanitised
     */
    private Neo4jExportJob startFromConfig(ExportRequest req,
                                            String networkVersion, String orgId) {
        if (req.getConfigId() == null || req.getConfigId().isBlank())
            throw new IllegalArgumentException(
                    "configId required when mode=FROM_CONFIG");

        Neo4jExportConfig cfg = configRepo.findById(req.getConfigId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Neo4jExportConfig not found: " + req.getConfigId()));

        boolean hasSpecificVariant = req.getVersionType() != null;

        if (hasSpecificVariant) {
            // Case 2: caller wants only one specific variant
            List<String> types = getTypesForVariant(cfg, req.getVersionType());
            if (types.isEmpty())
                throw new IllegalArgumentException(
                        "Config '" + cfg.getConfigName() + "' has no cimTypes for variant "
                        + req.getVersionType());
            log.info("FROM_CONFIG single variant: config='{}' variant={} types={}",
                    cfg.getConfigName(), req.getVersionType(), types.size());
            return startSingleExport(req, networkVersion, orgId, req.getVersionType(), types);
        }

        // Case 1: no versionType specified → trigger ALL configured variants
        // Build a multi-variant request from the stored config lists
        ExportRequest multiReq = new ExportRequest();
        multiReq.setJobId(req.getJobId());
        multiReq.setOrgId(orgId);
        multiReq.setClearFirst(req.isClearFirst());

        if (cfg.getFullCimTypes()           != null && !cfg.getFullCimTypes().isEmpty())
            multiReq.setFullCimTypes(cfg.getFullCimTypes());
        if (cfg.getSanitisedCimTypes()      != null && !cfg.getSanitisedCimTypes().isEmpty())
            multiReq.setSanitisedCimTypes(cfg.getSanitisedCimTypes());
        if (cfg.getRationalisedCimTypes()   != null && !cfg.getRationalisedCimTypes().isEmpty())
            multiReq.setRationalisedCimTypes(cfg.getRationalisedCimTypes());
        if (cfg.getCustomCimTypes()         != null && !cfg.getCustomCimTypes().isEmpty()) {
            multiReq.setCustomCimTypes(cfg.getCustomCimTypes());
            if (cfg.getCustomNeoVersion()   != null && !cfg.getCustomNeoVersion().isBlank())
                multiReq.setNeoVersion(cfg.getCustomNeoVersion());
        }

        if (!multiReq.isMultiVariant())
            throw new IllegalArgumentException(
                    "Config '" + cfg.getConfigName()
                    + "' has no cimTypes configured in any variant list.");

        log.info("FROM_CONFIG multi-variant: config='{}' full={} sanitised={} rationalised={}",
                cfg.getConfigName(),
                multiReq.getFullCimTypes().size(),
                multiReq.getSanitisedCimTypes().size(),
                multiReq.getRationalisedCimTypes().size());

        return startMultiVariantExport(multiReq, networkVersion, orgId);
    }

    private List<String> getTypesForVariant(Neo4jExportConfig cfg,
                                             ExportRequest.VersionType vType) {
        if (vType == ExportRequest.VersionType.FULL)
            return cfg.getFullCimTypes()      != null ? cfg.getFullCimTypes()      : new ArrayList<>();
        if (vType == ExportRequest.VersionType.RATIONALISED)
            return cfg.getRationalisedCimTypes() != null ? cfg.getRationalisedCimTypes() : new ArrayList<>();
        return cfg.getSanitisedCimTypes()     != null ? cfg.getSanitisedCimTypes() : new ArrayList<>();
    }

    /**
     * Triggers three separate export jobs — one per variant.
     * Each uses its own cimType list and version suffix.
     */
    private Neo4jExportJob startMultiVariantExport(ExportRequest req,
                                                    String networkVersion,
                                                    String orgId) {
        Neo4jExportJob firstJob = null;

        // FULL (-0)
        if (!req.getFullCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.FULL, req.getFullCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: FULL ({}-0) triggered — {} cimTypes",
                    networkVersion, req.getFullCimTypes().size());
        }

        // SANITISED (-1)
        if (!req.getSanitisedCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.SANITISED, req.getSanitisedCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: SANITISED ({}-1) triggered — {} cimTypes",
                    networkVersion, req.getSanitisedCimTypes().size());
        }

        // RATIONALISED (-2)
        if (!req.getRationalisedCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.RATIONALISED, req.getRationalisedCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: RATIONALISED ({}-2) triggered — {} cimTypes",
                    networkVersion, req.getRationalisedCimTypes().size());
        }

        // CUSTOM — REQ 6: user-provided version string
        if (!req.getCustomCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.CUSTOM, req.getCustomCimTypes());
            if (firstJob == null) firstJob = j;
            String custVer = req.getNeoVersion() != null ? req.getNeoVersion() : "custom";
            log.info("Multi-variant: CUSTOM ({}) triggered — {} cimTypes",
                    custVer, req.getCustomCimTypes().size());
        }

        return firstJob;
    }

    /**
     * ENHANCEMENT 3: Resolve FROM_CONFIG mode.
     * Loads cimType list from the specified Neo4jExportConfig document.
     */
    private List<String> resolveFromConfig(ExportRequest req,
                                            ExportRequest.VersionType vType) {
        if (req.getConfigId() == null || req.getConfigId().isBlank())
            throw new IllegalArgumentException(
                    "configId required when mode=FROM_CONFIG");
        Neo4jExportConfig cfg = configRepo.findById(req.getConfigId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Neo4jExportConfig not found: " + req.getConfigId()));
        List<String> types;
        if (vType == ExportRequest.VersionType.FULL)
            types = cfg.getFullCimTypes();
        else if (vType == ExportRequest.VersionType.RATIONALISED)
            types = cfg.getRationalisedCimTypes();
        else
            types = cfg.getSanitisedCimTypes();  // SANITISED default

        if (types == null || types.isEmpty())
            throw new IllegalArgumentException(
                    "Config '" + cfg.getConfigName() + "' has no cimTypes for variant "
                    + vType.name());
        log.info("FROM_CONFIG resolved: config='{}' variant={} types={}",
                cfg.getConfigName(), vType, types.size());
        return types;
    }

    private Neo4jExportJob startSingleExport(ExportRequest req,
                                              String networkVersion,
                                              String orgId,
                                              ExportRequest.VersionType vType,
                                              List<String> typesForVariant) {
        String exportId     = UUID.randomUUID().toString();
        String neo4jVersion = req.buildNeo4jVersion(networkVersion, vType);

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), neo4jVersion, orgId,
                "CUSTOM_" + vType.name());
        exportRepo.save(job);

        // Build a single-variant request for the executor
        ExportRequest singleReq = new ExportRequest(
                req.getJobId(),
                ExportRequest.ExportMode.CUSTOM,
                typesForVariant,
                req.isClearFirst());
        singleReq.setVersionType(vType);
        singleReq.setOrgId(orgId);

        executor.runAsync(singleReq, job);
        return job;
    }

    // ── Called by executor on async thread ───────────────────────────────

    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();
            constrainedLabels.clear();

            // Resolve effective orgId
            String orgId = job.getOrgId();
            // neo4jVersion already has suffix (e.g. "DB140-1")
            String neo4jVersion = job.getNetworkVersion();

            // Clear existing nodes if requested
            long nodesCleared = 0;
            if (req.isClearFirst()) {
                nodesCleared = clearExistingNodesCount(neo4jVersion, orgId);
            }

            // Use CREATE mode only if clearFirst=true AND clear succeeded (or was empty)
            // If clear failed midway, fall back to MERGE to avoid duplicates
            this.useBulkCreate = req.isClearFirst();
            // Note: clearExistingNodes logs warnings on partial failure
            // For production safety, MERGE handles duplicates even if clear was partial

            // Load non-CIM flags:
            //   includeNonCimNs    = include vendor ATTRIBUTES (caiso:, spc: etc.)
            //   includeNonCimNodes = include non-CIM NODES (category=UNKNOWN/null)
            this.includeNonCimNs    = false;
            this.includeNonCimNodes = req.isIncludeNonCim(); // request default=true

            if (req.getMode() == ExportRequest.ExportMode.FROM_CONFIG
                    && req.getConfigId() != null) {
                configRepo.findById(req.getConfigId()).ifPresent(cfg -> {
                    this.includeNonCimNs    = cfg.isIncludeNonCimNamespaces();
                    this.includeNonCimNodes = cfg.isIncludeNonCimNodes();
                });
            }
            log.info("includeNonCimNodes={} includeNonCimNs={}",
                    this.includeNonCimNodes, this.includeNonCimNs);

            // Create per-label constraints upfront
            createConstraintsUpfront(req);

            int[] counts = twoPassExport(req, job, neo4jVersion, orgId);

            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            log.info("Export DONE: mode={} version={} orgId={} nodes={} rels={} in {}",
                    req.getMode(), neo4jVersion, orgId, counts[0], counts[1],
                    com.cim.model.mongo.StageTimings.format(
                            System.currentTimeMillis() - start));

        } catch (Exception e) {
            log.error("Export FAILED: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);
        }
    }

    // ── Two-pass export ───────────────────────────────────────────────────

    private int[] twoPassExport(ExportRequest req, Neo4jExportJob job,
                                  String neo4jVersion, String orgId) {
        int totalNodes = 0, totalRels = 0;
        long total = mongo.count(new Query(buildCriteria(req)), "cim_objects");
        log.info("Pass 1 — {} nodes batch={} version={} orgId={}",
                total, batchSize, neo4jVersion, orgId);

        long start = System.currentTimeMillis();
        String lastId = null;
        int page = 0;

        // ── Pass 1: Nodes ─────────────────────────────────────────────────
        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalNodes += writeNodes(batch, neo4jVersion, orgId);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                long el   = System.currentTimeMillis() - start;
                long rate = el > 0 ? totalNodes * 1000L / el : 0;
                long eta  = rate > 0 ? (total - totalNodes) / rate / 60 : -1;
                log.info("Pass 1: page={} nodes={}/{} rate={}/s eta={}min",
                        page, totalNodes, total, rate, eta);
                job.setNodesExported(totalNodes);
                exportRepo.save(job);
            }
        }
        log.info("Pass 1 DONE — {} nodes in {}",
                totalNodes,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        // ENHANCEMENT 4: Create :OPEN custom nodes for switches with normalOpen=true
        // A switch with normalOpen=true means it is normally in OPEN state.
        // We create a separate :OPEN node connected to the switch to make this
        // clearly visible in the Neo4j graph topology.
        int openNodes = createOpenStateNodes(req.getJobId(), neo4jVersion, orgId);
        if (openNodes > 0)
            log.info("Enhancement 4: {} :OPEN state nodes created", openNodes);
        totalNodes += openNodes;

        // ── Pass 2: Relationships ─────────────────────────────────────────
        // Build pass-through index for topology collapse
        Set<String> exportedTypes = req.getCimTypes() != null
                ? new java.util.HashSet<>(req.getCimTypes())
                : java.util.Collections.emptySet();
        buildPassThroughIndex(req.getJobId(), exportedTypes);

        log.info("Pass 2 — relationships");
        start = System.currentTimeMillis();
        lastId = null; page = 0;

        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId);
            if (batch.isEmpty()) break;

            totalRels += writeRelationships(batch, neo4jVersion, orgId);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                log.info("Pass 2: page={} rels={}", page, totalRels);
                job.setRelsExported(totalRels);
                exportRepo.save(job);
            }
        }
        log.info("Pass 2 DONE — {} rels in {}",
                totalRels,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        // Free pass-through index memory
        passThroughIndex.clear();

        // ── Pass 3: Remove :CIMNode routing label ─────────────────────────
        // :CIMNode was added during export for fast O(log n) MATCH in Pass 2.
        // Now that export is complete, remove it — manager sees only clean
        // equipment labels (:ACLineSegment, :Breaker, :Substation etc.)
        log.info("Pass 3 — removing :CIMNode routing label...");
        long p3start = System.currentTimeMillis();
        long labelsRemoved = removeCimNodeLabel(neo4jVersion, orgId);
        log.info("Pass 3 DONE — :CIMNode removed from {} nodes in {}",
                labelsRemoved,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - p3start));

        return new int[]{totalNodes, totalRels};
    }

    // ── Write nodes — single cimType label only (REQ #2) ─────────────────

    private boolean useBulkCreate = false; // set true when clearFirst=true


    /**
     * Write nodes using CREATE (clearFirst) or MERGE (incremental).
     *
     * CREATE mode (clearFirst=true):
     *   - No duplicate check needed — nodes were just deleted
     *   - No index lookup per node — pure append write
     *   - 10-20x faster than MERGE: O(1) vs O(log n) per node
     *   - No MERGE scan degradation as node count grows
     *
     * MERGE mode (incremental):
     *   - Safe when existing nodes may be present
     *   - Uses per-label constraint for O(log n) lookup
     *   - Slower but correct for partial re-exports
     */
    private boolean includeNonCimNs    = false; // include vendor ATTRIBUTES on nodes
    private boolean includeNonCimNodes = false; // include non-CIM NODES in export

    /**
     * Topology collapse index: rdfId → PassThroughEntry for EXCLUDED objects.
     * Built before Pass 2, cleared after. Enables walk-through of excluded cimTypes
     * so excluded nodes act as transparent bridges in the topology graph.
     */
    private final java.util.concurrent.ConcurrentHashMap<String, PassThroughEntry>
            passThroughIndex = new java.util.concurrent.ConcurrentHashMap<>();

    private static class PassThroughEntry {
        final String cimType;
        final Map<String, String> refs; // attrName → targetRdfId (decoded)
        PassThroughEntry(String cimType, Map<String, String> refs) {
            this.cimType = cimType;
            this.refs    = refs != null ? refs : new java.util.LinkedHashMap<>();
        }
    }

    private int writeNodes(List<CimObjectRecord> records,
                            String neo4jVersion, String orgId) {
        if (records.isEmpty()) return 0;

        Map<String, List<Map<String, Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, neo4jVersion, orgId));
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String, Object>> nodeBatch = e.getValue();
                String cypher;

                if (useBulkCreate) {
                    // CREATE — pure append, no lookup, no index maintenance during write
                    // :CIMNode is a shared routing label added to ALL nodes.
                    // This enables ONE index (CIMNode.nodeKey) used by Pass 2 MATCH.
                    // Without it, MATCH (src {nodeKey:...}) scans all 953K nodes = slow.
                    // Users still query by specific label (:ACLineSegment etc).
                    cypher = "UNWIND $batch AS p " +
                             "CREATE (n:" + label + ":CIMNode) SET n = p";
                } else {
                    // MERGE — idempotent, uses per-label constraint
                    ensureLabelConstraint(s, label);
                    cypher = "UNWIND $batch AS p " +
                             "MERGE (n:" + label + ":CIMNode {nodeKey: p.nodeKey}) " +
                             "SET n += p";
                }

                final String fc = cypher;
                final List<Map<String, Object>> fb = nodeBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += nodeBatch.size();

                } catch (Neo4jException ex) {
                    log.warn("Node write failed {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodes: {}", e.getMessage());
        }
        return written;
    }

    // ── Build node properties — version type variant handling (REQ #3) ────

    private Map<String, Object> buildNodeProps(CimObjectRecord rec,
                                                String neo4jVersion,
                                                String orgId) {
        Map<String, Object> p = new LinkedHashMap<>();
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";
        String o = orgId         != null ? orgId           : "";

        // nodeKey uses neo4jVersion which already has suffix (e.g. "DB140-1")
        p.put("nodeKey",  r + "|" + neo4jVersion + "|" + o);
        p.put("mrid",     rec.getMrid()    != null ? rec.getMrid()    : r);
        p.put("rdfId",    r);
        p.put("name",     rec.getName()    != null ? rec.getName()    : "");
        p.put("cimType",  rec.getCimType() != null ? rec.getCimType() : "Unknown");
        p.put("version",  neo4jVersion);   // "DB140-0", "DB140-1", or "DB140-2"
        p.put("orgId",    o);
        p.put("category", rec.getCategory() != null ? rec.getCategory() : "");
        p.put("uri",      rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // REQ 3: Attribute filtering based on isCimStandard flag in namespace_configs
        // includeNonCimNs=true  → store all attributes (CIM standard + vendor)
        // includeNonCimNs=false → store only CIM standard attributes (no colon prefix)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes()).forEach((k, v) -> {
                if (k == null || v == null || v.isBlank()) return;
                boolean isVendorAttr = k.contains(":");
                if (!isVendorAttr || includeNonCimNs) {
                    p.put(k, v);
                }
            });
        }
        return p;
    }

    // ── Write relationships ───────────────────────────────────────────────

    private int writeRelationships(List<CimObjectRecord> records,
                                    String neo4jVersion, String orgId) {
        if (records.isEmpty()) return 0;

        // Collect all edges — using collectEdges() which handles topology collapse.
        // For each ref, if the target is an excluded cimType (in passThroughIndex),
        // the algorithm walks THROUGH it to find the next included node,
        // preserving the original first-hop attribute name as the relationship type.
        //
        // Group by relType for batched Cypher execution.
        Map<String, List<Map<String, Object>>> byRelType = new LinkedHashMap<>();

        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty()) continue;
            String srcRdfId = rec.getRdfId() != null ? rec.getRdfId() : "";

            // Decode keys and collect edges with topology collapse
            Map<String, String> decodedRefs =
                    MapKeySanitizer.decodeKeys(rec.getResolvedRefIds());

            List<Map<String, Object>> edges = new ArrayList<>();
            Set<String> visited = new java.util.HashSet<>();
            visited.add(srcRdfId); // prevent src→src cycles
            collectEdges(srcRdfId, decodedRefs, neo4jVersion, orgId,
                    edges, null, visited);

            for (Map<String, Object> edge : edges) {
                String relType = (String) edge.get("relType");
                byRelType.computeIfAbsent(relType, k -> new ArrayList<>()).add(edge);
            }
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byRelType.entrySet()) {
                String relType = e.getKey();
                List<Map<String, Object>> relBatch = e.getValue();
                String cypher =
                    "UNWIND $batch AS r " +
                    "MATCH (src:CIMNode {nodeKey: r.srcKey}) " +
                    "MATCH (tgt:CIMNode {nodeKey: r.tgtKey}) " +
                    "MERGE (src)-[:" + relType +
                    " {version: r.version, orgId: r.orgId}]->(tgt)";
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                try {
                    s.writeTransaction(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += relBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Rel write failed {}: {}", relType, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeRelationships: {}", e.getMessage());
        }
        return written;
    }

    // ── Constraint creation (upfront, per label) ──────────────────────────

    private void createConstraintsUpfront(ExportRequest req) {
        if (constrainedLabels.size() > 0) return;
        log.info("Creating constraints and indexes...");
        long start = System.currentTimeMillis();

        // Label-less indexes — no :CIMNode label needed.
        // Neo4j 4.4+ supports label-less indexes and uses them for
        // MATCH (n {nodeKey:...}) and MATCH (n {version:...}) queries.
        String[][] sharedIndexes = {
            // CRITICAL: used by Pass 2 MATCH (src {nodeKey: r.srcKey})
            {"nodekey_idx",
             "CREATE INDEX nodekey_idx IF NOT EXISTS FOR (n) ON (n.nodeKey)"},
            // Used by clearExistingNodes and version-filtered queries
            {"version_idx",
             "CREATE INDEX version_idx IF NOT EXISTS FOR (n) ON (n.version)"},
            // Used by org-filtered queries
            {"orgid_idx",
             "CREATE INDEX orgid_idx IF NOT EXISTS FOR (n) ON (n.orgId)"},
            // Used by mRID lookups
            {"mrid_idx",
             "CREATE INDEX mrid_idx IF NOT EXISTS FOR (n) ON (n.mrid)"},
        };
        for (String[] idx : sharedIndexes) {
            try (Session s = driver.session()) {
                s.run(idx[1]);
                log.debug("Index ensured: {}", idx[0]);
            } catch (Exception e) {
                log.debug("Index note {}: {}", idx[0], e.getMessage());
            }
        }
        log.info("Label-less indexes ready — Pass 2 MATCH uses nodekey_idx");

        org.springframework.data.mongodb.core.aggregation.Aggregation agg =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .match(buildCriteria(req)),
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .group("cimType")
            );

        List<org.bson.Document> results = mongo.aggregate(
                agg, "cim_objects", org.bson.Document.class).getMappedResults();

        int created = 0;
        for (org.bson.Document doc : results) {
            Object ct = doc.get("_id");
            if (ct == null) continue;
            String label = sanitizeLabel(ct.toString());
            if (constrainedLabels.contains(label)) continue;
            try (Session s = driver.session()) {
                s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                      "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
                constrainedLabels.add(label);
                created++;
            } catch (Exception e) {
                constrainedLabels.add(label);
            }
        }
        log.info("Constraints ready: {} labels in {}",
                constrainedLabels.size(),
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));
    }

    private void ensureLabelConstraint(Session s, String label) {
        if (constrainedLabels.contains(label)) return;
        try {
            s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                  "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
            constrainedLabels.add(label);
        } catch (Exception e) {
            constrainedLabels.add(label);
        }
    }

    // ── Clear existing nodes (batched, version+orgId scoped) ─────────────

    /**
     * Delete all nodes for a given version+orgId from Neo4j.
     *
     * THREE-STEP APPROACH (prevents transaction timeouts):
     *
     *   Step 1: Delete all RELATIONSHIPS first (batched).
     *           A Substation may have 50K+ relationships.
     *           DETACH DELETE 1000 nodes could mean deleting millions of rels
     *           in one transaction → TransactionDeadlockException / timeout.
     *           Deleting rels first makes DETACH DELETE safe (no rels left).
     *
     *   Step 2: Delete :CIMNode nodes (batch 5000 — fast, index-backed).
     *           All rels already gone → DETACH DELETE = simple node delete.
     *
     *   Step 3: Removed. No :CIMNode label used anymore.
     *
     * DUPLICATE RISK if clear fails:
     *   CREATE mode (useBulkCreate=true): creates NEW nodes regardless.
     *     → duplicates if old nodes exist. Clear MUST succeed.
     *   MERGE mode (useBulkCreate=false): upserts existing nodes.
     *     → no duplicates regardless. Clear just cleans old extra nodes.
     */
    private long clearExistingNodesCount(String neo4jVersion, String orgId) {
        clearExistingNodes(neo4jVersion, orgId);
        return 0L; // count logged inside clearExistingNodes
    }

    private void clearExistingNodes(String neo4jVersion, String orgId) {
        log.info("Clearing nodes: version={} orgId={}", neo4jVersion, orgId);
        long relsDeleted = 0, nodesDeleted = 0;

        // ── Step 1: Delete relationships first ───────────────────────────
        // Batch: 10000 rels per transaction (relationships are lightweight)
        log.info("Step 1: deleting relationships for version={} orgId={}",
                neo4jVersion, orgId);
        // Step 1: Delete relationships
        // FIX: consume Result INSIDE writeTransaction lambda — not outside.
        // In Neo4j Driver 4.4.x, Result is only valid within the transaction.
        // Accessing r.single() after writeTransaction() returns = result already closed.
        while (true) {
            try (Session s = driver.session()) {
                long d = s.writeTransaction(tx -> {
                    Result r = tx.run(
                        "MATCH (n {version: $v, orgId: $o})-[rel]-() " +
                        "WITH rel LIMIT 10000 DELETE rel RETURN count(rel) AS d",
                        Values.parameters("v", neo4jVersion, "o", orgId));
                    return r.single().get("d").asLong(); // consumed inside tx ✅
                });
                relsDeleted += d;
                if (d == 0) break;
            } catch (Exception e) {
                log.warn("Rel delete batch error (retrying): {}", e.getMessage());
                try { Thread.sleep(500); } catch (InterruptedException ie) { break; }
            }
        }
        log.info("Relationships deleted: {}", relsDeleted);

        // Step 2: Delete :CIMNode nodes
        log.info("Step 2: deleting nodes for version={} orgId={}",
                neo4jVersion, orgId);
        int retries = 0;
        while (retries < 3) {
            boolean hadError = false;
            while (true) {
                try (Session s = driver.session()) {
                    long d = s.writeTransaction(tx -> {
                        Result r = tx.run(
                            "MATCH (n {version: $v, orgId: $o}) " +
                            "WITH n LIMIT 5000 DELETE n RETURN count(n) AS d",
                            Values.parameters("v", neo4jVersion, "o", orgId));
                        return r.single().get("d").asLong(); // consumed inside tx ✅
                    });
                    nodesDeleted += d;
                    if (d == 0) break;
                } catch (Exception e) {
                    log.warn("Node delete batch error: {}", e.getMessage());
                    hadError = true;
                    break;
                }
            }
            if (!hadError) break;
            retries++;
            try { Thread.sleep(1000); } catch (InterruptedException ie) { break; }
        }

        // Step 3: Not needed. :CIMNode removed — Step 2 handles all nodes.

        log.info("Clear complete: {} relationships + {} nodes deleted (version={} orgId={})",
                relsDeleted, nodesDeleted, neo4jVersion, orgId);

        if (nodesDeleted == 0 && relsDeleted == 0)
            log.info("No existing data found for version={} orgId={} — fresh export",
                    neo4jVersion, orgId);
    }

    // ── Cursor pagination ─────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(ExportRequest req, String lastId) {
        Criteria criteria = buildCriteria(req);
        if (lastId != null && !lastId.isBlank()) {
            criteria = new Criteria().andOperator(
                    criteria,
                    Criteria.where("_id").gt(
                            new org.bson.types.ObjectId(lastId)));
        }
        return mongo.find(
                new Query(criteria)
                        .limit(batchSize)
                        .with(Sort.by(Sort.Direction.ASC, "_id")),
                CimObjectRecord.class, "cim_objects");
    }

    private Criteria buildCriteria(ExportRequest req) {
        String jobId = req.getJobId();

        // CUSTOM with cimTypes list — used by all multi-variant exports
        if (req.getMode() == ExportMode.CUSTOM
                && req.getCimTypes() != null && !req.getCimTypes().isEmpty()) {

            // includeNonCimNs=true: also export non-CIM objects (category=UNKNOWN/null)
            // alongside the explicit cimTypes list.
            // Non-CIM objects have cimType like "VendorWidget" — not in standard list.
            // Two ways to include them:
            //   1. Add their cimType names to the export config's cimTypes list (explicit)
            //   2. Set includeNonCimNamespaces=true on Neo4jExportConfig (automatic)
            if (includeNonCimNodes) {
                return new Criteria().andOperator(
                        Criteria.where("jobId").is(jobId),
                        new Criteria().orOperator(
                                Criteria.where("cimType").in(req.getCimTypes()),
                                Criteria.where("category").is("UNKNOWN"),
                                Criteria.where("category").isNull()
                        )
                );
            }
            return Criteria.where("jobId").is(jobId)
                    .and("cimType").in(req.getCimTypes());
        }

        if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            if (includeNonCimNodes) {
                // PHYSICAL + vendor types (UNKNOWN/null category)
                return new Criteria().andOperator(
                        Criteria.where("jobId").is(jobId),
                        new Criteria().orOperator(
                                Criteria.where("category").is("PHYSICAL"),
                                Criteria.where("category").is("UNKNOWN"),
                                Criteria.where("category").isNull()
                        )
                );
            }
            return Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL");
        }
        if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            return Criteria.where("jobId").is(jobId).and("isRequired").is(true);
        }
        if (req.getMode() == ExportMode.TOPOLOGY) {
            List<String> logicalTypes = Arrays.asList(
                    "Terminal","ConnectivityNode","TopologicalNode","TopologicalIsland");
            List<Criteria> orList = new ArrayList<>();
            orList.add(Criteria.where("category").is("PHYSICAL"));
            orList.add(Criteria.where("cimType").in(logicalTypes));
            if (includeNonCimNodes) {
                orList.add(Criteria.where("category").is("UNKNOWN"));
                orList.add(Criteria.where("category").isNull());
            }
            return new Criteria().andOperator(
                    Criteria.where("jobId").is(jobId),
                    new Criteria().orOperator(
                            orList.toArray(new Criteria[0]))
            );
        }
        // ALL mode — returns everything including non-CIM nodes by default
        return Criteria.where("jobId").is(jobId);
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Topology Collapse — Pass-Through Index ───────────────────────────

    /**
     * Builds the pass-through index before Pass 2.
     *
     * Queries cim_objects for ALL objects whose cimType is NOT in the export list.
     * Stores their rdfId + resolvedRefIds in passThroughIndex for O(1) lookup
     * during collectEdges() walk.
     *
     * Uses lightweight projection — only rdfId, cimType, resolvedRefIds.
     * No attributes loaded — keeps memory footprint small.
     *
     * @param jobId       import job ID
     * @param exportedTypes  set of cimTypes being exported (from export config)
     */
    private void buildPassThroughIndex(String jobId, Set<String> exportedTypes) {
        passThroughIndex.clear();
        if (exportedTypes.isEmpty()) return;

        log.info("Building pass-through index for topology collapse...");
        long start = System.currentTimeMillis();

        // Stream excluded objects in pages — never load all at once
        int PAGE = 2000;
        String lastId = null;
        long total = 0;

        while (true) {
            // Criteria: same job, cimType NOT in export list
            Criteria criteria = Criteria.where("jobId").is(jobId)
                    .and("cimType").not().in(exportedTypes);
            if (lastId != null)
                criteria = new Criteria().andOperator(criteria,
                        Criteria.where("_id").gt(
                                new org.bson.types.ObjectId(lastId)));

            // Projection: only fields needed for topology walk — no attributes
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(criteria)
                            .limit(PAGE)
                            .with(org.springframework.data.domain.Sort.by(
                                    org.springframework.data.domain.Sort.Direction.ASC, "_id"));
            q.fields()
                    .include("rdfId")
                    .include("cimType")
                    .include("resolvedRefIds");

            List<com.cim.model.mongo.CimObjectRecord> batch =
                    mongo.find(q, com.cim.model.mongo.CimObjectRecord.class, "cim_objects");

            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();

            for (com.cim.model.mongo.CimObjectRecord rec : batch) {
                if (rec.getRdfId() == null) continue;
                // Decode resolvedRefIds keys (U+FF0E → dot)
                Map<String, String> decodedRefs = rec.getResolvedRefIds() != null
                        ? MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                        : new java.util.LinkedHashMap<>();
                passThroughIndex.put(rec.getRdfId(),
                        new PassThroughEntry(rec.getCimType(), decodedRefs));
                total++;
            }
        }

        log.info("Pass-through index built: {} excluded objects in {}ms — "
                + "topology collapse enabled for excluded cimTypes",
                total, System.currentTimeMillis() - start);
    }

    /**
     * Collect edges from a source object's resolvedRefIds, collapsing through
     * any excluded cimTypes encountered.
     *
     * For each ref:
     *   - If target is an INCLUDED node → emit edge directly
     *   - If target is an EXCLUDED node → walk through its refs recursively
     *     until we reach an INCLUDED node (or exhaust all paths)
     *   - Cycle protection via visitedRdfIds set
     *
     * @param srcRdfId      rdfId of the source (included) object
     * @param refs          resolvedRefIds of the source (attrName → targetRdfId)
     * @param neo4jVersion  version string for nodeKey
     * @param orgId         orgId for nodeKey
     * @param edges         output — list of (srcKey, tgtKey, relType) maps
     * @param firstHopName  the original attribute name from the very first hop
     *                      (preserved as relType when collapsing through excluded)
     * @param visited       cycle protection — rdfIds already visited in this walk
     */
    private void collectEdges(String srcRdfId, Map<String, String> refs,
                               String neo4jVersion, String orgId,
                               List<Map<String, Object>> edges,
                               String firstHopName,
                               Set<String> visited) {
        if (refs == null || refs.isEmpty()) return;
        String o = orgId != null ? orgId : "";

        for (Map.Entry<String, String> entry : refs.entrySet()) {
            String attrName   = entry.getKey();   // e.g. "Terminal.ConductingEquipment"
            String targetRdfId = entry.getValue(); // e.g. "_line1"
            if (targetRdfId == null || targetRdfId.isBlank()) continue;

            // Determine the relationship type for this edge:
            // If we are at the first hop: use attrName as-is
            // If we are in a recursive walk: preserve the ORIGINAL first-hop name
            String relType = firstHopName != null ? firstHopName : attrName;

            if (passThroughIndex.containsKey(targetRdfId)) {
                // Target is EXCLUDED — collapse through it
                if (visited.contains(targetRdfId)) continue; // cycle protection
                visited.add(targetRdfId);

                PassThroughEntry excluded = passThroughIndex.get(targetRdfId);
                // Recurse: walk through the excluded object's own refs
                // Keep original relType (firstHopName) for the eventual edge
                collectEdges(srcRdfId, excluded.refs,
                        neo4jVersion, orgId, edges,
                        relType,   // preserve first-hop name through all levels
                        visited);
            } else {
                // Target is INCLUDED — emit direct edge
                Map<String, Object> edge = new java.util.LinkedHashMap<>();
                edge.put("srcKey",  srcRdfId    + "|" + neo4jVersion + "|" + o);
                edge.put("tgtKey",  targetRdfId + "|" + neo4jVersion + "|" + o);
                edge.put("version", neo4jVersion);
                edge.put("orgId",   o);
                edge.put("relType", "`" + relType.replace("`", "") + "`");
                edges.add(edge);
            }
        }
    }

    // ── Pass 3: Remove :CIMNode routing label after export ───────────────

    /**
     * Removes :CIMNode label from all nodes for a specific version+orgId.
     * Called after Pass 2 completes — nodes keep their equipment labels only.
     * Batched to avoid transaction timeouts.
     */
    private long removeCimNodeLabel(String neo4jVersion, String orgId) {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                long removed = s.writeTransaction(tx -> {
                    Result r = tx.run(
                        "MATCH (n:CIMNode {version: $v, orgId: $o}) " +
                        "WITH n LIMIT 5000 REMOVE n:CIMNode RETURN count(n) AS removed",
                        Values.parameters("v", neo4jVersion, "o", orgId));
                    return r.single().get("removed").asLong();
                });
                total += removed;
                if (removed == 0) break;
            } catch (Exception e) {
                log.warn("CIMNode label removal batch error: {}", e.getMessage());
                break;
            }
        }
        return total;
    }

    // ── Cleanup legacy labels ─────────────────────────────────────────────

    public long removeLegacyLabels() {
        long total = 0;
        for (String label : Arrays.asList("CIMObject")) {
            while (true) {
                try (Session s = driver.session()) {
                    String cypher = "MATCH (n:" + label + ") WITH n LIMIT 1000 " +
                                    "REMOVE n:" + label + " RETURN count(n) AS r";
                    long removed = s.writeTransaction(tx -> {
                        Result r = tx.run(cypher);
                        return r.single().get("r").asLong(); // consumed inside tx ✅
                    });
                    total += removed;
                    if (removed == 0) break;
                    log.info("Removed :{} from {} nodes", label, removed);
                } catch (Exception e) { break; }
            }
        }
        log.info("Legacy label cleanup: {} nodes updated", total);
        return total;
    }

    // ── Enhancement 4: OPEN state nodes for switches ─────────────────────

    /**
     * Creates a custom :OPEN node for every switch with normalOpen=true.
     *
     * WHY:
     *   In CIM, Switch.normalOpen=true means the switch is normally OPEN.
     *   This is a critical topological state — open switches break the
     *   electrical path in the network.
     *
     * WHAT IS CREATED:
     *   For each switch (Breaker/Fuse/Disconnector/Recloser) with normalOpen=true:
     *     - An :OPEN node representing the open state
     *     - A [:IS_NORMALLY_OPEN] relationship from the switch to the :OPEN node
     *
     *   Result in Neo4j:
     *     (breaker:Breaker {name:'BKR-01', normalOpen:'true'})
     *       -[:IS_NORMALLY_OPEN]→ (:OPEN {switchName:'BKR-01', version:'DB140-1'})
     *
     * SWITCH TYPES CHECKED: Breaker, Fuse, Disconnector, Recloser, Switch,
     *                        LoadBreakSwitch, GroundDisconnector, Jumper
     */
    private int createOpenStateNodes(String jobId, String neo4jVersion, String orgId) {
        List<String> switchTypes = Arrays.asList(
            "Breaker", "Fuse", "Disconnector", "Recloser",
            "Switch", "LoadBreakSwitch", "GroundDisconnector", "Jumper"
        );

        // Build criteria for switches with normalOpen=true
        String normalOpenKey = com.cim.util.MapKeySanitizer.encode("Switch.normalOpen");
        Criteria criteria = new Criteria().andOperator(
                Criteria.where("jobId").is(jobId),
                Criteria.where("cimType").in(switchTypes),
                new Criteria().orOperator(
                        Criteria.where("attributes." + normalOpenKey).is("true"),
                        Criteria.where("attributes." + com.cim.util.MapKeySanitizer.encode("Breaker.normalOpen")).is("true"),
                        Criteria.where("attributes." + com.cim.util.MapKeySanitizer.encode("Fuse.normalOpen")).is("true"),
                        Criteria.where("attributes." + com.cim.util.MapKeySanitizer.encode("Disconnector.normalOpen")).is("true"),
                        Criteria.where("attributes." + com.cim.util.MapKeySanitizer.encode("Recloser.normalOpen")).is("true")
                )
        );

        // FIX 1: Count first — avoid loading all records if none found
        long count = mongo.count(new Query(criteria), "cim_objects");
        if (count == 0) {
            log.info("Enhancement 4: no switches with normalOpen=true — skipping");
            return 0;
        }
        log.info("Enhancement 4: {} switches with normalOpen=true", count);

        int totalCreated = 0;
        int OPEN_BATCH   = 500; // small batch — each record is large

        // FIX 2: Cursor pagination — never load all switches at once
        String lastId = null;
        while (true) {
            Criteria pageCriteria = criteria;
            if (lastId != null) {
                pageCriteria = new Criteria().andOperator(
                        criteria,
                        Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
            }
            List<com.cim.model.mongo.CimObjectRecord> batch = mongo.find(
                    new Query(pageCriteria)
                            .limit(OPEN_BATCH)
                            .with(org.springframework.data.domain.Sort.by(
                                    org.springframework.data.domain.Sort.Direction.ASC, "_id")),
                    com.cim.model.mongo.CimObjectRecord.class, "cim_objects");

            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();

            // Build OPEN node maps for this batch
            // Group by switchType for label-specific MERGE
            Map<String, List<Map<String, Object>>> byType = new LinkedHashMap<>();
            List<Map<String, Object>> relBatch = new ArrayList<>();

            for (com.cim.model.mongo.CimObjectRecord sw : batch) {
                String nodeKey = sw.getRdfId() + "_OPEN|" + neo4jVersion + "|" + orgId;
                Map<String, Object> p = new LinkedHashMap<>();
                p.put("nodeKey",    nodeKey);
                p.put("switchKey",  sw.getRdfId() + "|" + neo4jVersion + "|" + orgId);
                p.put("switchName", sw.getName() != null ? sw.getName() : "");
                p.put("switchType", sw.getCimType());
                p.put("switchRdfId",sw.getRdfId());
                p.put("version",    neo4jVersion);
                p.put("orgId",      orgId);
                p.put("state",      "OPEN");
                String switchLabel = sanitizeLabel(sw.getCimType());
                byType.computeIfAbsent(switchLabel, k -> new ArrayList<>()).add(p);
                relBatch.add(p);
            }

            try (Session s = driver.session()) {
                // Write :OPEN nodes per switchType label
                for (Map.Entry<String, List<Map<String, Object>>> e : byType.entrySet()) {
                    String switchLabel = e.getKey();
                    List<Map<String, Object>> typeBatch = e.getValue();
                    // :OPEN:Breaker — shows correct type in Neo4j Browser
                    String createCypher =
                        "UNWIND $batch AS p " +
                        "MERGE (o:OPEN:" + switchLabel + " {nodeKey: p.nodeKey}) " +
                        "SET o = p";
                    final List<Map<String, Object>> fb = typeBatch;
                    s.writeTransaction(tx -> {
                        tx.run(createCypher, Values.parameters("batch", fb));
                        return null;
                    });
                    totalCreated += typeBatch.size();
                }

                // FIX 3: Create IS_NORMALLY_OPEN relationships — batched
                // FIX 2: sw MATCH uses :CIMNode for O(log n) index lookup
                String relCypher =
                    "UNWIND $batch AS p " +
                    "MATCH (sw:CIMNode {nodeKey: p.switchKey}) " +
                    "MATCH (o:OPEN {nodeKey: p.nodeKey}) " +
                    "MERGE (sw)-[:IS_NORMALLY_OPEN {version: p.version, orgId: p.orgId}]->(o)";
                final List<Map<String, Object>> fb = relBatch;
                s.writeTransaction(tx -> {
                    tx.run(relCypher, Values.parameters("batch", fb));
                    return null;
                });
            } catch (Exception e) {
                log.warn("OPEN node batch error: {}", e.getMessage());
            }
        }

        log.info("Enhancement 4: {} :OPEN nodes created", totalCreated);
        return totalCreated;
    }

    // ── Migration — add :CIMNode to existing nodes ───────────────────────

    /** Removed: migrateAddCimNodeLabel no longer needed — :CIMNode removed. */

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
